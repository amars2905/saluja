package saluja.com.saluja.Api;

public class URLs {
    public static final String URL_REGISTER = "http://62.210.110.20:100/api/register";
    public static final String URL_LOGIN= "http://62.210.110.20:100/api/login";

    public static final String URL_PRODUCT_LIST= "https://salujacart.com/wp-json/wc/v1/products?per_page=100";
    public static final String URL_PRODUCT_LIST1= "https://salujacart.com/wp-json/wc/v1/products?page=";
    public static final String URL_FAV= "http://62.210.110.20:100/api/favoriteShow";
    public static final String URL_ADD_FAV= "http://62.210.110.20:100/api/favoriteAdd";
    public static final String URL_PLAY_ALL= "http://62.210.110.20:100/api/playAll";
    public static final String URL_PRODUCT_DETAIL= "https://salujacart.com/wp-json/wc/v1/products/";

}
